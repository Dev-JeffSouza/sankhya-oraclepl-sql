CREATE OR REPLACE TRIGGER JS_TGR_RECALC_UPD 
AFTER UPDATE OF DTINI, DTFIN ON AD_TMTFAT
FOR EACH ROW

BEGIN
	
	IF (:NEW.DTINI <> :OLD.DTINI OR :NEW.DTFIN <> :OLD.DTFIN) THEN

		--Chamadas para recalcular as telas

		--Resultado dos Produtos
		JS_STP_CALC_RES_PRO (
			P_DTINI   => :NEW.DTINI, 
            P_DTFIN   => :NEW.DTFIN, 
            P_CODMETA => :NEW.CODMETA
        );
		--Resultado dos Vendedores
		JS_STP_CALC_META_VEN (
			P_DTINI   => :NEW.DTINI, 
            P_DTFIN   => :NEW.DTFIN, 
            P_CODMETA => :NEW.CODMETA
        );
		--Resultado dos Vendedores/Parceiros
		JS_STP_CALC_RES_VEN_PCR (
			P_DTINI   => :NEW.DTINI, 
            P_DTFIN   => :NEW.DTFIN, 
            P_CODMETA => :NEW.CODMETA
        );
		--Resultado dos Vendedores/Produtos
		JS_STP_CALC_RES_VEN_PRO (
			P_DTINI   => :NEW.DTINI, 
            P_DTFIN   => :NEW.DTFIN, 
            P_CODMETA => :NEW.CODMETA
        );
		
	END IF;

END;
